# Agente local de impressao

```powershell
pip install -r requirements.txt
copy config.example.json config.json
python agent.py
```

O agente roda no Windows, consulta a API por jobs pendentes, faz `claim`, imprime na impressora local e retorna `success` ou `fail`.
